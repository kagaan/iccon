# iOS 27 Beta Light icon pack project

Contains the extracted icon artwork and a partial `appfilter.xml` mapping from the supplied ZTH archive. It is an Android project, not a prebuilt APK.

## Build without Android Studio
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. Follow `TELEFONDAN_APK_ALMA.txt` to upload this project to a GitHub repository and download the generated debug APK from Actions > Artifacts.

## Current limitations
The project is a basic Android app shell with artwork and a partial appfilter. It does not yet implement a complete launcher-specific icon-pack dashboard/protocol, and ColorOS compatibility has not been tested. APK build success does not guarantee that ColorOS will list or apply the pack.
