package com.example.ios27icons;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  TextView view = new TextView(this);
  view.setText("iOS 27 Beta Light icon pack\\n\\nThis project includes the icon artwork and appfilter.xml.\\nLauncher-specific icon pack integration may require additional compatibility code.");
  view.setPadding(32,32,32,32);
  setContentView(view);
 }
}
